package com.example.aichatbotcc17;

import okhttp3.*;

public class OpenAIClient {

    private static final String API_KEY = "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"; // Insert your API key here
    private static final String API_URL = "https://api.openai.com/v1/completions";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private OkHttpClient client;

    public OpenAIClient() {
        client = new OkHttpClient();
    }

    public void sendMessage(String prompt, Callback callback) {
        String json = "{\"model\": \"text-davinci-003\", \"prompt\": \"" + prompt + "\", \"max_tokens\": 150}";
        RequestBody body = RequestBody.create(json, JSON);
        Request request = new Request.Builder()
                .url(API_URL)
                .header("Authorization", "Bearer " + API_KEY)
                .post(body)
                .build();

        client.newCall(request).enqueue(callback);
    }
}
