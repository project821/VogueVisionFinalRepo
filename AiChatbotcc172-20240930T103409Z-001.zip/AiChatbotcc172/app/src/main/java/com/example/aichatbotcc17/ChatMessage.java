package com.example.aichatbotcc17;

public class ChatMessage {
    private String message;
    private boolean isBot; // To distinguish between user and bot messages

    public ChatMessage(String message, boolean isBot) {
        this.message = message;
        this.isBot = isBot;
    }

    public String getMessage() {
        return message;
    }

    public boolean isBot() {
        return isBot;
    }
}
