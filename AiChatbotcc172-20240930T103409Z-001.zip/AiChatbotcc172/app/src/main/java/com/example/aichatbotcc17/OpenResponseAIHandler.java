package com.example.aichatbotcc17;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import java.io.IOException;

class OpenAIResponseHandler {

    public static String parseResponse(String responseBody) {
        JsonObject jsonObject = JsonParser.parseString(responseBody).getAsJsonObject();
        String responseText = jsonObject.getAsJsonArray("choices")
                .get(0).getAsJsonObject()
                .get("text").getAsString().trim();
        return responseText;
    }

    public static void handleOpenAIResponse(Call call, Response response, final MainActivity activity) throws IOException {
        if (response.isSuccessful()) {
            String responseBody = response.body().string();
            String botMessage = parseResponse(responseBody);

            activity.runOnUiThread(() -> activity.addMessage(botMessage, true));
        } else {
            activity.runOnUiThread(() -> activity.addMessage("Error: Unable to connect to AI server.", true));
        }
    }
}

