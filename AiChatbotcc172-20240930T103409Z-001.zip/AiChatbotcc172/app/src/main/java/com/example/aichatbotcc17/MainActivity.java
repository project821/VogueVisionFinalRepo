package com.example.aichatbotcc17;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> chatMessages = new ArrayList<>();
    private EditText editTextMessage;
    private Button buttonSend;
    private OpenAIClient openAIClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        editTextMessage = findViewById(R.id.editTextMessage);
        buttonSend = findViewById(R.id.buttonSend);
        openAIClient = new OpenAIClient();

        chatAdapter = new ChatAdapter(chatMessages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(chatAdapter);

        buttonSend.setOnClickListener(view -> {
            String userMessage = editTextMessage.getText().toString();
            if (!userMessage.isEmpty()) {
                addMessage(userMessage, false);
                editTextMessage.setText("");
                botResponse(userMessage);
            }
        });
    }

    public void addMessage(String message, boolean isBot) {
        chatMessages.add(new ChatMessage(message, isBot));
        chatAdapter.notifyDataSetChanged();
        recyclerView.scrollToPosition(chatMessages.size() - 1);
    }

    private void botResponse(String userMessage) {
        openAIClient.sendMessage(userMessage, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> addMessage("Error: Failed to get a response.", true));
            }

            @Override
            public void onResponse(Call call, okhttp3.Response response) throws IOException {
                OpenAIResponseHandler.handleOpenAIResponse(call, response, MainActivity.this);
            }
        });
    }
}
